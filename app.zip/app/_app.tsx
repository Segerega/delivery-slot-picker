import '../styles/globals.css'; // Import global CSS styles
import { AuthProvider } from '../context/AuthContext'; // Import AuthProvider

function MyApp({ Component, pageProps }) {
    return (
        <AuthProvider>
            <Component {...pageProps} /> {/* This renders the current page */}
        </AuthProvider>
    );
}

export default MyApp;
