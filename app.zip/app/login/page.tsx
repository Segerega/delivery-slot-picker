"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowRightOnRectangleIcon } from '@heroicons/react/24/outline';
import { useAuth } from '../context/AuthContext'; // Import AuthContext

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const router = useRouter();
    const { login } = useAuth(); // Get login function from context

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });

            const data = await response.json();

            if (data.error) {
                setErrorMessage(data.error);
            } else {
                setErrorMessage('');
                login(data.user.name); // Log in user and set their name in context
                router.push('/slots'); // Redirect to slots page
            }
        } catch (error) {
            setErrorMessage('An error occurred during login');
        }
    };

    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-cyan-50 via-cyan-100 to-cyan-200 p-6">
            <h1 className="text-4xl font-bold text-center text-gray-900 mb-6">Login</h1>
            {errorMessage && <p className="text-red-500">{errorMessage}</p>}
            <form onSubmit={handleSubmit} className="bg-white shadow-lg rounded-lg p-8 w-full max-w-md">
                <div className="mb-4">
                    <label className="block text-gray-700 text-lg font-bold mb-2" htmlFor="username">
                        Username
                    </label>
                    <input
                        id="username"
                        type="text"
                        placeholder="Enter your username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400"
                    />
                </div>

                <div className="mb-6">
                    <label className="block text-gray-700 text-lg font-bold mb-2" htmlFor="password">
                        Password
                    </label>
                    <input
                        id="password"
                        type="password"
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400"
                    />
                </div>

                <button
                    type="submit"
                    className="w-full bg-pink-500 text-white py-3 px-6 rounded-lg shadow-lg hover:bg-emerald-700 transition duration-300 flex items-center justify-center"
                >
                    <ArrowRightOnRectangleIcon className="h-6 w-6 mr-2" />
                    Login
                </button>
            </form>

            <p className="mt-4 text-gray-700">
                Don't have an account?{' '}
                <button className="text-teal-500 hover:text-teal-700" onClick={() => router.push('/register')}>
                    Register
                </button>
            </p>
        </div>
    );
};

export default Login;
