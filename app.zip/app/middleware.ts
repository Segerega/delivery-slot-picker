import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(req: NextRequest) {
    const token = req.cookies.get('authToken');  // Get the auth token from cookies

    // If the user is trying to access /slots and doesn't have the token, redirect to /login
    if (!token && req.nextUrl.pathname === '/slots') {
        return NextResponse.redirect(new URL('/login', req.url));
    }

    // Allow the request to continue if authenticated
    return NextResponse.next();
}

// Apply the middleware to the /slots route
export const config = {
    matcher: ['/slots'],
};
