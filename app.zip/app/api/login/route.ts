import { NextResponse } from 'next/server';
import bcrypt from 'bcrypt';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(request: Request) {
    const { username, password } = await request.json();

    const user = await prisma.user.findUnique({
        where: { username },
    });

    if (!user) {
        return NextResponse.json({ error: 'Invalid username or password' }, { status: 401 });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
        return NextResponse.json({ error: 'Invalid username or password' }, { status: 401 });
    }

    // Set a cookie named 'authToken' with some token
    const response = NextResponse.json({ success: true, message: 'Login successful' });
    response.cookies.set('authToken', 'your_token_value', { path: '/', httpOnly: true });

    return response;
}
